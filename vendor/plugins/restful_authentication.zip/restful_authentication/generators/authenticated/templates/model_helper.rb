module <%= model_controller_class_name %>Helper
end